<?php
/*
 * ARI Quiz EasySocial User Points Joomla! plugin
 *
 * @package		ARI Quiz EasySocial User Points
 * @version		1.0.0
 * @author		ARI Soft
 * @copyright	Copyright (c) 2009 www.ari-soft.com. All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
 * 
 */

defined('_JEXEC') or die('Restricted access');

class plgSystemariquizeasysocialuserpointsInstallerScript
{
	function preflight($type, $parent)
	{
		$type = strtolower($type);
		if ($type == 'install')
			if (!$this->installPointsRules())
				return false;
	}

	function installPointsRules()
	{
		$frameworkPath = JPATH_ADMINISTRATOR . '/components/com_easysocial/includes/foundry.php';
		
		if (!file_exists($frameworkPath))
		{
            $frameworkPath = JPATH_ADMINISTRATOR . '/components/com_easysocial/includes/easysocial.php';

            if (!file_exists($frameworkPath))
            {
                $app = JFactory::getApplication();
                $app->enqueueMessage(
                    'Points rules were not installed becased EasySocial component is not installed.',
                    'error'
                );

                return false;
            }
		}

        require_once $frameworkPath;
		
		$pointsObj = Foundry::points();
		$pathToRulesFile = dirname(__FILE__) . '/quiz.points';
		if (!$pointsObj->discover($pathToRulesFile))
		{
			$app = JFactory::getApplication();
			$app->enqueueMessage(
				'Points rules were not installed. Install it manually using quiz.points file from plg_system_ariquizeasysocialuserpoints.zip archive.',
				'warning'
			);
		}

		return true;
	}
}