<?php
/*
 * ARI Quiz EasySocial User Points Joomla! plugin
 *
 * @package		ARI Quiz EasySocial User Points
 * @version		1.0.0
 * @author		ARI Soft
 * @copyright	Copyright (c) 2009 www.ari-soft.com. All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
 * 
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class plgSystemAriquizeasysocialuserpoints extends JPlugin
{ 
	/*
	 * Constructor
	 */
	function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
	}

	/*
	 * This method calls when user finishes quiz
	 * 
	 * @param    array  $params    Hash with the following keys
	 * 
	 * StatisticsInfoId
	 * UserName - user name
	 * QuizName - quiz name
	 * PassedScore - passed score
	 * MaxScore - max score
	 * UserScore - user score
	 * PercentScore - percent score
	 * _Passed - passed or not (1 or 0)
	 * StartDate - start date
	 * EndDate - end date
	 * SpentTime - spent time
	 * QuizId - quiz id
	 * 
	 * @access   public
	 */
	function onEndQuiz($quizParams)
	{
		$user = JFactory::getUser();
		$userId = $user->get('id');

		if ($userId == 0)
			return ;

		if (!$this->_loadEasySocialFramework()) 
			return ;

		$params = $this->params;
		$isPassed = $quizParams['_Passed'];

		$user = JFactory::getUser();
		$cmd = $isPassed ? 'quiz.complete' : 'quiz.fail';
		$pointsObj = Foundry::points();

		$pointsRule = Foundry::table( 'Points' );
		if (!$pointsRule->load(array('command' => $cmd, 'extension' => 'com_ariquiz')) || $pointsRule->state != SOCIAL_STATE_PUBLISHED)
			return ;

		AriKernel::import('SimpleTemplate.SimpleTemplate');

		$points = $pointsRule->points;
		$message = AriSimpleTemplate::parse($pointsRule->description, $quizParams);
		$pointsObj->assignCustom($userId, $points, $message);
	}

	/*
	 * This method loads EasySocial framework
	 * 
	 * @access   private
	 */
	function _loadEasySocialFramework()
	{
		$frameworkPath = JPATH_ADMINISTRATOR . '/components/com_easysocial/includes/foundry.php';
		
		if (!file_exists($frameworkPath))
        {
            $frameworkPath = JPATH_ADMINISTRATOR . '/components/com_easysocial/includes/easysocial.php';
            if (!file_exists($frameworkPath))
			    return false;
        }

		require_once $frameworkPath;
		
		return true;
	}
}